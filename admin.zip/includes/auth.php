<?php
session_start();

function requireLogin() {
    if (!isset($_SESSION['admin'])) {
        header('Location: /admin/login.php');
        exit;
    }
}
<?php
$db_host = 'localhost';
$db_user = 'u2911633_sfera';
$db_pass = '39912121Ucod'; // Замените на реальный пароль
$db_name = 'u2911633_sfera';

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($db->connect_error) {
    error_log("Ошибка подключения к базе данных: " . $db->connect_error, 3, '/var/www/u2911633/data/www/new.sitdgo.pro/php_errors.log');
    die("Ошибка подключения к базе данных. Пожалуйста, попробуйте позже.");
}

$db->set_charset('utf8mb4');
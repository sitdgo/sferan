<?php
require_once 'includes/functions.php';
require_once 'includes/db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $db->prepare("SELECT * FROM objects WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$object = $stmt->get_result()->fetch_assoc();

if (!$object) {
    header('HTTP/1.1 404 Not Found');
    die('Объект не найден');
}

$images_data = json_decode($object['images'], true);
$images = $images_data['files'] ?? [];
$captions = $images_data['captions'] ?? [];
$main_image = $images_data['main'] ?? 0;

// Генерация мета-тегов
$meta_title = htmlspecialchars($object['title']) . ' - Сфера-Н';
$meta_description = 'Продажа ' . ($object['category'] == 'apartment' ? 'квартиры' : ($object['category'] == 'house' ? 'дома' : 'коммерческой недвижимости')) . ' в ' . htmlspecialchars($object['city']) . ' за ' . number_format($object['price'], 2) . ' ₽. Площадь: ' . $object['area'] . ' м².';
$meta_keywords = 'недвижимость, ' . htmlspecialchars($object['city']) . ', ' . ($object['category'] == 'apartment' ? 'квартира' : ($object['category'] == 'house' ? 'дом' : 'коммерческая недвижимость')) . ', купить, ' . ($object['status'] == 'available' ? 'доступно' : ($object['status'] == 'sold' ? 'продано' : 'в резерве'));

$renovation_labels = [
    'no_renovation' => 'Без ремонта',
    'designer' => 'Дизайнерский',
    'euro' => 'Евроремонт',
    'cosmetic' => 'Косметический',
    'rough' => 'Черновая отделка',
    'pre_finishing' => 'Предчистовая отделка',
    'finished' => 'Чистовая отделка'
];

// Массив для перевода подписей к фотографиям
$caption_labels = [
    'interior' => 'Интерьер',
    'view_from_window' => 'Вид из окна'
];
?>

<h1 data-aos="fade-up"><?php echo htmlspecialchars($object['title']); ?></h1>
<div class="object-details" data-aos="fade-up">
    <div class="slider">
        <div class="slider-track">
            <?php foreach ($images as $index => $image): ?>
                <div class="slide <?php echo $index === $main_image ? 'active' : ''; ?>">
                    <picture>
                        <source srcset="/assets/<?php echo str_replace('.jpg', '.webp', $image); ?>" type="image/webp">
                        <img src="/assets/<?php echo $image; ?>" alt="<?php echo htmlspecialchars($object['title']); ?>" loading="lazy">
                    </picture>
                </div>
            <?php endforeach; ?>
        </div>
        <button class="slider-prev"><img src="/assets/icons/chevron-left.svg" alt="Предыдущий"></button>
        <button class="slider-next"><img src="/assets/icons/chevron-right.svg" alt="Следующий"></button>
        <div class="slider-thumbnails">
            <?php foreach ($images as $index => $image): ?>
                <div class="thumbnail-wrapper">
                    <img src="/assets/<?php echo $image; ?>" alt="Миниатюра" class="thumbnail <?php echo $index === $main_image ? 'active' : ''; ?>" data-index="<?php echo $index; ?>">
                    <?php if (!empty($captions[$index])): ?>
                        <span class="thumbnail-caption"><?php echo htmlspecialchars($caption_labels[$captions[$index]] ?? $captions[$index]); ?></span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Улучшенное отображение деталей объекта -->
    <div class="details">
        <!-- Основные характеристики -->
        <div class="details-section">
            <h3>Основные характеристики</h3>
            <div class="details-grid">
                <div class="details-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <strong>Цена:</strong> <?php echo number_format($object['price'], 2); ?> ₽
                </div>
                <div class="details-item">
                    <i class="fas fa-home"></i>
                    <strong>Категория:</strong> <?php echo $object['category'] == 'apartment' ? 'Квартира' : ($object['category'] == 'house' ? 'Дом' : 'Коммерческая'); ?>
                </div>
                <div class="details-item">
                    <i class="fas fa-ruler-combined"></i>
                    <strong>Площадь:</strong> <?php echo $object['area']; ?> м²
                </div>
                <div class="details-item">
                    <i class="fas fa-door-open"></i>
                    <strong>Комнат:</strong> <?php echo $object['rooms'] ?? 'Нет данных'; ?>
                </div>
                <?php if ($object['floors']): ?>
                    <div class="details-item">
                        <i class="fas fa-building"></i>
                        <strong>Этажей в доме:</strong> <?php echo $object['floors']; ?>
                    </div>
                <?php endif; ?>
                <?php if ($object['floor']): ?>
                    <div class="details-item">
                        <i class="fas fa-layer-group"></i>
                        <strong>Этаж:</strong> <?php echo $object['floor']; ?>
                    </div>
                <?php endif; ?>
                <div class="details-item">
                    <i class="fas fa-paint-roller"></i>
                    <strong>Ремонт:</strong> <?php echo $renovation_labels[$object['renovation']] ?? 'Не указан'; ?>
                </div>
                <div class="details-item">
                    <i class="fas fa-check-circle"></i>
                    <strong>Статус:</strong> <?php echo $object['status'] == 'available' ? 'Доступен' : ($object['status'] == 'sold' ? 'Продан' : 'В резерве'); ?>
                </div>
            </div>
        </div>

        <!-- Расположение -->
        <div class="details-section">
            <h3>Расположение</h3>
            <div class="details-grid">
                <div class="details-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <strong>Адрес:</strong> <?php echo htmlspecialchars($object['address']); ?>
                </div>
                <div class="details-item">
                    <i class="fas fa-city"></i>
                    <strong>Город:</strong> <?php echo htmlspecialchars($object['city']); ?>
                </div>
            </div>
        </div>

        <!-- Описание -->
        <div class="details-section">
            <h3>Описание</h3>
            <p class="description"><?php echo nl2br(htmlspecialchars($object['description'])); ?></p>
        </div>
    </div>

    <!-- Форма -->
    <form method="POST" action="/index.php?page=send_request" class="contact-form">
        <input type="hidden" name="object_id" value="<?php echo $id; ?>">
        <div class="filter-group">
            <label>Имя:</label>
            <input type="text" name="name" placeholder="Ваше имя" required>
        </div>
        <div class="filter-group">
            <label>Email:</label>
            <input type="email" name="email" placeholder="Ваш email" required>
        </div>
        <div class="filter-group">
            <label>Телефон:</label>
            <input type="tel" name="phone" placeholder="Ваш телефон">
        </div>
        <div class="filter-group">
            <label>Сообщение:</label>
            <textarea name="message" placeholder="Ваш запрос" required></textarea>
        </div>
        <button type="submit">Отправить запрос</button>
    </form>
    <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        <p class="success">Ваш запрос успешно отправлен!</p>
    <?php endif; ?>
</div>

<!-- JavaScript для слайдера -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sliderTrack = document.querySelector('.slider-track');
        const slides = sliderTrack.querySelectorAll('.slide');
        const thumbnails = document.querySelectorAll('.thumbnail');
        const prevButton = document.querySelector('.slider-prev');
        const nextButton = document.querySelector('.slider-next');

        let currentIndex = Array.from(slides).findIndex(slide => slide.classList.contains('active'));

        function updateSlider(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            thumbnails.forEach(thumb => thumb.classList.remove('active'));
            slides[index].classList.add('active');
            thumbnails[index].classList.add('active');
            currentIndex = index;
        }

        // Клик по кнопке "Предыдущий"
        prevButton.addEventListener('click', function () {
            let newIndex = currentIndex - 1;
            if (newIndex < 0) newIndex = slides.length - 1;
            updateSlider(newIndex);
        });

        // Клик по кнопке "Следующий"
        nextButton.addEventListener('click', function () {
            let newIndex = currentIndex + 1;
            if (newIndex >= slides.length) newIndex = 0;
            updateSlider(newIndex);
        });

        // Клик по миниатюре
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function () {
                const index = parseInt(this.getAttribute('data-index'));
                updateSlider(index);
            });
        });
    });
</script>
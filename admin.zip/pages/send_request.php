<?php
require_once 'includes/functions.php';
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = isset($_POST['phone']) ? sanitize($_POST['phone']) : NULL;
    $message = sanitize($_POST['message']);
    $object_id = isset($_POST['object_id']) ? intval($_POST['object_id']) : NULL;

    $stmt = $db->prepare("INSERT INTO requests (name, email, phone, message, object_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('ssssi', $name, $email, $phone, $message, $object_id);
    $stmt->execute();

    $redirect = isset($_POST['object_id']) ? "/index.php?page=object&id=$object_id&success=1" : "/index.php?page=contacts&success=1";
    header("Location: $redirect");
    exit;
}
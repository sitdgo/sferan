<?php
// /var/www/u2911633/data/www/new.sitdgo.pro/pages/home.php
?>

<!-- Предотвращение кэширования -->
<meta http-equiv="cache-control" content="no-cache, must-revalidate, post-check=0, pre-check=0">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">

<!-- Подключение стилей и нового скрипта для слайдера -->
<link rel="stylesheet" href="/assets/css/services-slider.css">
<script src="/assets/js/custom-slider.js" defer></script>

<section id="hero" class="section">
    <div class="container">
        <h1>Добро пожаловать в СФЕРА Н</h1>
        <p>Ваше агентство недвижимости в Дальнегорске</p>
    </div>
</section>

<!-- Раздел "Мы предлагаем" -->
<section id="services" class="section">
    <div class="container">
        <h2 data-aos="fade-up">Мы предлагаем</h2>
        <p class="section-description" data-aos="fade-up">Вы хотите быстро и эффективно продать свою недвижимость в Дальнегорске? Наш профессиональный подход гарантирует максимально комфортный процесс.</p>
        <div class="services-slider" data-aos="fade-up">
            <div class="slider-track">
                <?php
                if (!$db) {
                    echo "<!-- Ошибка: Подключение к базе данных отсутствует -->";
                } else {
                    $services = $db->query("SELECT * FROM services ORDER BY id ASC");
                    if ($services === false) {
                        echo "<!-- Ошибка в запросе: " . $db->error . " -->";
                    } else {
                        $total_services = $services->num_rows;
                        echo "<!-- Отладка: Всего записей в базе: $total_services -->";
                        $loaded_services = 0;
                        if ($total_services > 0) {
                            while ($service = $services->fetch_assoc()) {
                                $loaded_services++;
                                $image = file_exists("/var/www/u2911633/data/www/new.sitdgo.pro/assets/" . $service['image']) 
                                    ? $service['image'] 
                                    : 'placeholder.jpg';
                                $title = htmlspecialchars($service['title'] ?? "Услуга $loaded_services");
                                $description = htmlspecialchars($service['description'] ?? "Описание услуги $loaded_services");
                                echo "<!-- Отладка: Загружаю услугу ID: " . htmlspecialchars($service['id']) . ", Title: $title, Image: $image, Description: $description -->";
                                ?>
                                <div class="service-item slide">
                                    <img src="/assets/<?php echo $image; ?>" alt="<?php echo $title; ?>" class="service-image">
                                    <h3><?php echo $title; ?></h3>
                                    <p><?php echo $description; ?></p>
                                </div>
                                <?php
                            }
                        } else {
                            echo "<!-- Ошибка: Нет записей в таблице services -->";
                        }
                        echo "<!-- Отладка: Загружено слайдов в HTML: $loaded_services -->";
                    }
                }
                ?>
            </div>
            <?php if (isset($total_services) && $total_services > 0): ?>
                <button class="slider-prev"><img src="/assets/icons/chevron-left.svg" alt="Предыдущий"></button>
                <button class="slider-next"><img src="/assets/icons/chevron-right.svg" alt="Следующий"></button>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Раздел "Наши объекты" (слайдер) -->
<section id="objects" class="section">
    <div class="container">
        <h2>Наши объекты</h2>
        <div class="objects-slider">
            <?php if (isset($objects) && is_array($objects) && count($objects) > 0): ?>
                <?php foreach ($objects as $object): ?>
                    <div class="object-item">
                        <?php
                        $images_data = json_decode($object['images'], true);
                        $main_image = isset($images_data['files']) && isset($images_data['main']) && isset($images_data['files'][$images_data['main']]) 
                            ? $images_data['files'][$images_data['main']] 
                            : 'images/placeholder.jpg';
                        ?>
                        <img src="/assets/<?php echo htmlspecialchars($main_image); ?>" alt="<?php echo htmlspecialchars($object['title']); ?>">
                        <h3><?php echo htmlspecialchars($object['title']); ?></h3>
                        <p><?php echo isset($object['price']) ? number_format($object['price'], 2) : 'Цена по запросу'; ?> ₽</p>
                        <p><?php echo htmlspecialchars($object['city'] ?? 'Не указан город'); ?></p>
                        <a href="/index.php?page=object&id=<?php echo isset($object['id']) ? $object['id'] : '#'; ?>" class="btn">Подробнее</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Объекты отсутствуют.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Новый нижний блок -->
<section id="about-agency" class="section">
    <div class="container">
        <h2>Агентство недвижимости СФЕРА Н в Дальнегорске</h2>
        <p>СФЕРА Н — агентство недвижимости в Дальнегорске, предлагающее полный комплекс услуг: продажа, покупка, обмен, срочный выкуп, аренда, приватизация, помощь в оформлении наследства и ипотеки. Работаем с материнским капиталом и сертификатами. Обеспечиваем индивидуальный подход и полное сопровождение сделок. Надежность, оперативность и профессионализм — наши ключевые принципы.</p>
    </div>
</section>
<?php
require_once 'includes/functions.php';
require_once 'includes/db.php';

$per_page = 9;
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $per_page;

$where = [];
$params = [];
$types = '';

$city = isset($_GET['city']) ? sanitize($_GET['city']) : '';
$price_min = isset($_GET['price_min']) && $_GET['price_min'] !== '' ? floatval($_GET['price_min']) : 0;
$price_max = isset($_GET['price_max']) && $_GET['price_max'] !== '' ? floatval($_GET['price_max']) : PHP_INT_MAX;
$area_min = isset($_GET['area_min']) && $_GET['area_min'] !== '' ? floatval($_GET['area_min']) : 0;
$area_max = isset($_GET['area_max']) && $_GET['area_max'] !== '' ? floatval($_GET['area_max']) : PHP_INT_MAX;
$rooms = isset($_GET['rooms']) && $_GET['rooms'] !== '' ? intval($_GET['rooms']) : 0;
$status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'created_at DESC';

if ($city) {
    $where[] = "city = ?";
    $params[] = $city;
    $types .= 's';
}
if ($price_min > 0) {
    $where[] = "price >= ?";
    $params[] = $price_min;
    $types .= 'd';
}
if ($price_max < PHP_INT_MAX) {
    $where[] = "price <= ?";
    $params[] = $price_max;
    $types .= 'd';
}
if ($area_min > 0) {
    $where[] = "area >= ?";
    $params[] = $area_min;
    $types .= 'd';
}
if ($area_max < PHP_INT_MAX) {
    $where[] = "area <= ?";
    $params[] = $area_max;
    $types .= 'd';
}
if ($rooms > 0) {
    $where[] = "rooms = ?";
    $params[] = $rooms;
    $types .= 'i';
}
if ($status) {
    $where[] = "status = ?";
    $params[] = $status;
    $types .= 's';
}

$where_clause = $where ? "WHERE " . implode(" AND ", $where) : "";
$total_query = "SELECT COUNT(*) FROM objects $where_clause";
$stmt = $db->prepare($total_query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = $stmt->get_result()->fetch_row()[0];
$pages = ceil($total / $per_page);

$query = "SELECT * FROM objects $where_clause ORDER BY $sort LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;
$types .= 'ii';

$stmt = $db->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$objects = $stmt->get_result();

$cities = $db->query("SELECT DISTINCT city FROM objects WHERE city IS NOT NULL ORDER BY city")->fetch_all(MYSQLI_ASSOC);

// Генерация мета-тегов
$meta_parts = [];
if ($city) $meta_parts[] = "в $city";
if ($rooms > 0) $meta_parts[] = "$rooms-комнатные";
if ($status == 'available') $meta_parts[] = 'доступные';
elseif ($status == 'sold') $meta_parts[] = 'проданные';
elseif ($status == 'reserved') $meta_parts[] = 'в резерве';
$meta_title = 'Каталог недвижимости' . (!empty($meta_parts) ? ' ' . implode(', ', $meta_parts) : '') . ' - Сфера-Н';
$meta_description = 'Найдите идеальную недвижимость в каталоге Сфера-Н' . (!empty($meta_parts) ? ': ' . implode(', ', $meta_parts) : '') . '. Квартиры, дома и коммерческая недвижимость в Дальнегорске.';
$meta_keywords = 'недвижимость, Дальнегорск' . (!empty($meta_parts) ? ', ' . implode(', ', $meta_parts) : '') . ', квартиры, дома, коммерческая недвижимость';
?>

<h1 data-aos="fade-up">Каталог недвижимости</h1>
<form class="filter" method="GET" data-aos="fade-up">
    <input type="hidden" name="page" value="catalog">
    <div class="filter-group">
        <label>Город:</label>
        <select name="city">
            <option value="">Все</option>
            <?php foreach ($cities as $c): ?>
                <option value="<?php echo htmlspecialchars($c['city']); ?>" <?php echo $city == $c['city'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($c['city']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="filter-group">
        <label>Цена, ₽:</label>
        <div class="range-input">
            <input type="number" name="price_min" placeholder="От" min="0" value="<?php echo $price_min > 0 ? $price_min : ''; ?>">
            <input type="number" name="price_max" placeholder="До" min="0" value="<?php echo $price_max < PHP_INT_MAX ? $price_max : ''; ?>">
        </div>
    </div>
    <div class="filter-group">
        <label>Площадь, м²:</label>
        <div class="range-input">
            <input type="number" name="area_min" placeholder="От" min="0" step="0.1" value="<?php echo $area_min > 0 ? $area_min : ''; ?>">
            <input type="number" name="area_max" placeholder="До" min="0" step="0.1" value="<?php echo $area_max < PHP_INT_MAX ? $area_max : ''; ?>">
        </div>
    </div>
    <div class="filter-group">
        <label>Комнат:</label>
        <select name="rooms">
            <option value="">Все</option>
            <option value="1" <?php echo $rooms == 1 ? 'selected' : ''; ?>>1</option>
            <option value="2" <?php echo $rooms == 2 ? 'selected' : ''; ?>>2</option>
            <option value="3" <?php echo $rooms == 3 ? 'selected' : ''; ?>>3</option>
            <option value="4" <?php echo $rooms >= 4 ? 'selected' : ''; ?>>4+</option>
        </select>
    </div>
    <div class="filter-group">
        <label>Статус:</label>
        <select name="status">
            <option value="">Все</option>
            <option value="available" <?php echo $status == 'available' ? 'selected' : ''; ?>>Доступен</option>
            <option value="sold" <?php echo $status == 'sold' ? 'selected' : ''; ?>>Продан</option>
            <option value="reserved" <?php echo $status == 'reserved' ? 'selected' : ''; ?>>В резерве</option>
        </select>
    </div>
    <div class="filter-group">
        <label>Сортировка объявлений:</label>
        <select name="sort">
            <option value="created_at DESC" <?php echo $sort == 'created_at DESC' ? 'selected' : ''; ?>>Новые</option>
            <option value="price ASC" <?php echo $sort == 'price ASC' ? 'selected' : ''; ?>>Дешевые</option>
            <option value="price DESC" <?php echo $sort == 'price DESC' ? 'selected' : ''; ?>>Дорогие</option>
            <option value="area ASC" <?php echo $sort == 'area ASC' ? 'selected' : ''; ?>>Меньшая площадь</option>
            <option value="area DESC" <?php echo $sort == 'area DESC' ? 'selected' : ''; ?>>Большая площадь</option>
        </select>
    </div>
    <div class="filter-buttons">
        <button type="submit">Применить фильтр</button>
        <button type="button" onclick="resetFilter()">Сбросить фильтр</button>
    </div>
</form>

<div class="catalog" data-aos="fade-up">
    <?php while ($object = $objects->fetch_assoc()): ?>
        <div class="card">
            <?php
            $images_data = json_decode($object['images'], true);
            $images = $images_data['files'] ?? [];
            $main_image = $images_data['main'] ?? 0;
            $main_image_file = $images[$main_image] ?? 'images/placeholder.jpg';
            ?>
            <picture>
                <source srcset="/assets/<?php echo str_replace('.jpg', '.webp', $main_image_file); ?>" type="image/webp">
                <img src="/assets/<?php echo $main_image_file; ?>" alt="<?php echo htmlspecialchars($object['title']); ?>" loading="lazy">
            </picture>
            <h2><?php echo htmlspecialchars($object['title']); ?></h2>
            <p>Цена: <?php echo number_format($object['price'], 2); ?> ₽</p>
            <p>Площадь: <?php echo $object['area']; ?> м²</p>
            <p class="status-<?php echo $object['status']; ?>">
                <?php echo $object['status'] == 'available' ? 'Доступен' : ($object['status'] == 'sold' ? 'Продан' : 'В резерве'); ?>
            </p>
            <a href="/index.php?page=object&id=<?php echo $object['id']; ?>">Подробнее</a>
        </div>
    <?php endwhile; ?>
</div>

<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="/index.php?page=catalog&p=<?php echo $page - 1; ?>&<?php echo http_build_query($_GET, '', '&'); ?>">❮ Предыдущая</a>
    <?php endif; ?>
    <?php for ($i = 1; $i <= $pages; $i++): ?>
        <a href="/index.php?page=catalog&p=<?php echo $i; ?>&<?php echo http_build_query($_GET, '', '&'); ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>
    <?php if ($page < $pages): ?>
        <a href="/index.php?page=catalog&p=<?php echo $page + 1; ?>&<?php echo http_build_query($_GET, '', '&'); ?>">Следующая ❯</a>
    <?php endif; ?>
</div>

<script>
    function resetFilter() {
        const form = document.querySelector('.filter');
        form.reset();
        form.submit();
    }
</script>
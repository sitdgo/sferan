<?php
// Указываем правильный путь к includes/db.php
require_once dirname(__FILE__, 2) . '/includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $message = $_POST['message'] ?? '';

    // Отладка: выведем данные в лог
    error_log("Form submitted: Name=$name, Phone=$phone, Message=$message");

    // Здесь должна быть ваша логика (например, сохранение в базу данных или отправка email)
    // Пример: сохранение в базу данных
    $stmt = $db->prepare("INSERT INTO contacts (name, phone, message, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", $name, $phone, $message);
    $stmt->execute();

    header('Location: /?success=1'); // Редирект на главную с подтверждением
    exit;
} else {
    // Если файл вызывается напрямую через GET, редирект на главную
    header('Location: /');
    exit;
}
?>

<h1 data-aos="fade-up">Контакты</h1>
<div class="contacts" data-aos="fade-up" data-aos-delay="100">
    <p><strong>Адрес:</strong> Приморский край, г. Дальнегорск, пр-кт 50 лет Октября, д. 68</p>
    <p><strong>Телефон:</strong> <a href="tel:+79241370101">+7 (924) 137-01-01</a></p>
    <p><strong>Email:</strong> <a href="mailto:sphere_n2023@mail.ru">sphere_n2023@mail.ru</a></p>
    <p><strong>График работы:</strong> пн-пт с 10:00 до 17:00, перерыв с 13:00 до 14:00 сб-вс: ВЫХОДНОЙ</p>
</div>

<form method="POST" class="contact-form" data-aos="fade-up" data-aos-delay="200">
    <h2>Свяжитесь с нами</h2>
    <?php if (isset($success)): ?>
        <p class="success"><?php echo $success; ?></p>
    <?php endif; ?>
    <div class="filter-group">
        <label for="name">Имя:</label>
        <input type="text" id="name" name="name" placeholder="Ваше имя" required>
    </div>
    <div class="filter-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Ваш email" required>
    </div>
    <div class="filter-group">
        <label for="phone">Телефон:</label>
        <input type="tel" id="phone" name="phone" placeholder="Ваш телефон">
    </div>
    <div class="filter-group">
        <label for="message">Сообщение:</label>
        <textarea id="message" name="message" placeholder="Ваше сообщение" required></textarea>
    </div>
    <button type="submit" class="btn">Отправить</button>
</form>
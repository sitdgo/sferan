<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $message = sanitize($_POST['message']);
    
    $stmt = $db->prepare("INSERT INTO requests (name, email, phone, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $name, $email, $phone, $message);
    $stmt->execute();
    
    $success = "Ваш запрос отправлен! Мы свяжемся с вами в ближайшее время.";
}
?>

<h1 data-aos="fade-up">Контакты</h1>
<div class="contacts" data-aos="fade-up" data-aos-delay="100">
    <p><strong>Адрес:</strong> г. Дальнегорск, ул. Приморская, д. 10</p>
    <p><strong>Телефон:</strong> <a href="tel:+74237312345">+7 (42373) 1-23-45</a></p>
    <p><strong>Email:</strong> <a href="mailto:info@sfera-n.ru">info@sfera-n.ru</a></p>
    <p><strong>График работы:</strong> Пн-Пт: 9:00-18:00, Сб: 10:00-14:00</p>
</div>

<form method="POST" class="contact-form" data-aos="fade-up" data-aos-delay="200">
    <h2>Свяжитесь с нами</h2>
    <?php if (isset($success)): ?>
        <p class="success"><?php echo $success; ?></p>
    <?php endif; ?>
    <div class="filter-group">
        <label>Имя:</label>
        <input type="text" name="name" placeholder="Ваше имя" required>
    </div>
    <div class="filter-group">
        <label>Email:</label>
        <input type="email" name="email" placeholder="Ваш email" required>
    </div>
    <div class="filter-group">
        <label>Телефон:</label>
        <input type="tel" name="phone" placeholder="Ваш телефон">
    </div>
    <div class="filter-group">
        <label>Сообщение:</label>
        <textarea name="message" placeholder="Ваше сообщение" required></textarea>
    </div>
    <button type="submit">Отправить</button>
</form>
<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Временная проверка логина и пароля (без MySQL)
    if ($username === 'admin' && $password === '000000') {
        $_SESSION['admin'] = true;
        header('Location: /admin/index.php');
        exit;
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в админ-панель - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h1>Вход в админ-панель</h1>
            <?php if (isset($error)): ?>
                <p class="error-message"><?php echo $error; ?></p>
            <?php endif; ?>
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">Логин:</label>
                    <input type="text" id="username" name="username" placeholder="Логин" required>
                </div>
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" placeholder="Пароль" required>
                </div>
                <button type="submit" class="button primary">Войти</button>
            </form>
        </div>
    </div>
</body>
</html>
<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$objects_by_status = $db->query("SELECT status, COUNT(*) as count FROM objects GROUP BY status")->fetch_all(MYSQLI_ASSOC);
$objects_by_category = $db->query("SELECT category, COUNT(*) as count FROM objects GROUP BY category")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Статистика - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php" class="active"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Статистика</h1>
            </div>
            <div class="stats">
                <h2>Объекты по статусу</h2>
                <table>
                    <tr>
                        <th>Статус</th>
                        <th>Количество</th>
                    </tr>
                    <?php foreach ($objects_by_status as $stat): ?>
                        <tr>
                            <td><?php echo $stat['status'] == 'available' ? 'Доступен' : ($stat['status'] == 'sold' ? 'Продан' : 'В резерве'); ?></td>
                            <td><?php echo $stat['count']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <div class="stats">
                <h2>Объекты по категории</h2>
                <table>
                    <tr>
                        <th>Категория</th>
                        <th>Количество</th>
                    </tr>
                    <?php foreach ($objects_by_category as $stat): ?>
                        <tr>
                            <td><?php echo $stat['category'] == 'apartment' ? 'Квартира' : ($stat['category'] == 'house' ? 'Дом' : 'Коммерческая'); ?></td>
                            <td><?php echo $stat['count']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
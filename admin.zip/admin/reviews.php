<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$per_page = 15;
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $per_page;

// Обработка удаления
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $stmt = $db->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: /admin/reviews.php?p=$page");
    exit;
}

// Обработка обновления статуса
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $toggle_id = intval($_GET['toggle']);
    $stmt = $db->prepare("UPDATE reviews SET status = IF(status = 'published', 'draft', 'published') WHERE id = ?");
    $stmt->bind_param("i", $toggle_id);
    $stmt->execute();
    header("Location: /admin/reviews.php?p=$page");
    exit;
}

$total = $db->query("SELECT COUNT(*) FROM reviews")->fetch_row()[0];
$pages = ceil($total / $per_page);

$reviews = $db->query("SELECT * FROM reviews ORDER BY created_at DESC LIMIT $per_page OFFSET $offset");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отзывы - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php" class="active"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Отзывы</h1>
                <!-- Кнопка для добавления нового отзыва (опционально) -->
                <a href="/admin/reviews-add.php" class="button secondary">Добавить отзыв</a>
            </div>
            <div class="table-wrapper">
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Имя</th>
                        <th>Текст</th>
                        <th>Рейтинг</th>
                        <th>Статус</th>
                        <th>Дата</th>
                        <th>Действия</th>
                    </tr>
                    <?php while ($review = $reviews->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $review['id']; ?></td>
                            <td><?php echo htmlspecialchars($review['name']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($review['text'])); ?></td>
                            <td><?php echo $review['rating'] ?? 'N/A'; ?></td>
                            <td><?php echo ucfirst($review['status'] ?? 'draft'); ?></td>
                            <td><?php echo date('d.m.Y H:i', strtotime($review['created_at'])); ?></td>
                            <td class="actions">
                                <a href="/admin/reviews.php?toggle=<?php echo $review['id']; ?>&p=<?php echo $page; ?>" class="button <?php echo $review['status'] === 'published' ? 'danger' : 'secondary'; ?>">
                                    <?php echo $review['status'] === 'published' ? 'Скрыть' : 'Опубликовать'; ?>
                                </a>
                                <button type="button" class="button danger delete-btn" data-id="<?php echo $review['id']; ?>">Удалить</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            </div>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="/admin/reviews.php?p=<?php echo $page - 1; ?>">❮ Предыдущая</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a href="/admin/reviews.php?p=<?php echo $i; ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                <?php if ($page < $pages): ?>
                    <a href="/admin/reviews.php?p=<?php echo $page + 1; ?>">Следующая ❯</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.delete-btn');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    if (confirm('Вы уверены, что хотите удалить этот отзыв?')) {
                        window.location.href = `/admin/reviews.php?delete=${id}&p=<?php echo $page; ?>`;
                    }
                });
            });
        });
    </script>
</body>
</html>
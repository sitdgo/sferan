<?php
require_once '../../includes/auth.php';
require_once '../../includes/db.php';
requireLogin();

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID не указан']);
    exit;
}

$id = intval($_GET['id']);
$stmt = $db->prepare("SELECT * FROM services WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$service = $stmt->get_result()->fetch_assoc();

if ($service) {
    echo json_encode($service);
} else {
    echo json_encode(['error' => 'Услуга не найдена']);
}
exit;
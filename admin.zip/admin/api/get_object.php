<?php
require_once '../../includes/auth.php';
require_once '../../includes/db.php';
requireLogin();

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'ID не указан']);
    exit;
}

$id = intval($_GET['id']);
$stmt = $db->prepare("SELECT * FROM objects WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$object = $stmt->get_result()->fetch_assoc();

if ($object) {
    echo json_encode($object);
} else {
    echo json_encode(['error' => 'Объект не найден']);
}
exit;
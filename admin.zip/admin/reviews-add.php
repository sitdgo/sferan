<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $db->real_escape_string(trim($_POST['name'] ?? ''));
    $text = $db->real_escape_string(trim($_POST['text'] ?? ''));
    $rating = isset($_POST['rating']) && is_numeric($_POST['rating']) ? intval($_POST['rating']) : 0;
    $status = $db->real_escape_string(trim($_POST['status'] ?? 'draft'));

    // Валидация
    if (empty($name) || empty($text) || $rating < 0 || $rating > 5) {
        $error = "Пожалуйста, заполните все поля корректно. Рейтинг должен быть от 0 до 5.";
    } else {
        $stmt = $db->prepare("INSERT INTO reviews (name, text, rating, status, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssis", $name, $text, $rating, $status);
        if ($stmt->execute()) {
            header("Location: /admin/reviews.php?success=1");
            exit;
        } else {
            $error = "Ошибка при добавлении отзыва.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить отзыв - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Добавить отзыв</h1>
                <a href="/admin/reviews.php" class="button secondary">Назад к списку</a>
            </div>
            <?php if (isset($error)): ?>
                <div class="notification error"><?php echo htmlspecialchars($error); ?></div>
            <?php elseif (isset($_GET['success']) && $_GET['success'] == 1): ?>
                <div class="notification success">Отзыв успешно добавлен!</div>
            <?php endif; ?>
            <div class="modal-content" style="margin: 15px 0;">
                <form method="POST" class="login-form">
                    <div class="form-group">
                        <label for="name">Имя:</label>
                        <input type="text" id="name" name="name" placeholder="Введите имя" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="text">Текст отзыва:</label>
                        <textarea id="text" name="text" placeholder="Введите текст отзыва" required><?php echo htmlspecialchars($_POST['text'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="rating">Рейтинг (0-5):</label>
                        <input type="number" id="rating" name="rating" placeholder="Введите рейтинг" min="0" max="5" required value="<?php echo htmlspecialchars($_POST['rating'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status">Статус:</label>
                        <select id="status" name="status" required>
                            <option value="draft" <?php echo (isset($_POST['status']) && $_POST['status'] === 'draft') ? 'selected' : ''; ?>>Черновик</option>
                            <option value="published" <?php echo (isset($_POST['status']) && $_POST['status'] === 'published') ? 'selected' : ''; ?>>Опубликовано</option>
                        </select>
                    </div>
                    <button type="submit" class="button primary">Добавить отзыв</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
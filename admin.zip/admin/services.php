<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireLogin();

// Обработка добавления сервиса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $image = '';

    if (!empty($_FILES['image']['name'])) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $fileName = $_FILES['image']['name'];
        $fileTmp = $_FILES['image']['tmp_name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $newFileName = uniqid() . '.' . $fileExt;
        $uploadDir = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/uploads/';
        $dest = $uploadDir . $newFileName;

        if (in_array($fileExt, $allowed) && move_uploaded_file($fileTmp, $dest)) {
            $webpDest = $uploadDir . uniqid() . '.webp';
            $imageResource = imagecreatefromstring(file_get_contents($dest));
            if ($imageResource) {
                imagewebp($imageResource, $webpDest, 80);
                imagedestroy($imageResource);
                unlink($dest);
                $image = 'uploads/' . basename($webpDest);
            } else {
                $image = 'uploads/' . $newFileName;
            }
        }
    }

    $stmt = $db->prepare("INSERT INTO services (title, description, image) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $title, $description, $image);
    $stmt->execute();
    header('Location: /admin/services.php?success=added');
    exit;
}

// Обработка редактирования сервиса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = intval($_POST['id']);
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);

    $stmt = $db->prepare("SELECT image FROM services WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $current_image = $stmt->get_result()->fetch_assoc()['image'];

    $image = $current_image;
    if (!empty($_FILES['image']['name'])) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $fileName = $_FILES['image']['name'];
        $fileTmp = $_FILES['image']['tmp_name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $newFileName = uniqid() . '.' . $fileExt;
        $uploadDir = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/uploads/';
        $dest = $uploadDir . $newFileName;

        if (in_array($fileExt, $allowed) && move_uploaded_file($fileTmp, $dest)) {
            $webpDest = $uploadDir . uniqid() . '.webp';
            $imageResource = imagecreatefromstring(file_get_contents($dest));
            if ($imageResource) {
                imagewebp($imageResource, $webpDest, 80);
                imagedestroy($imageResource);
                unlink($dest);
                $image = 'uploads/' . basename($webpDest);
            } else {
                $image = 'uploads/' . $newFileName;
            }
            // Удаляем старое изображение
            if ($current_image && file_exists('/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $current_image)) {
                unlink('/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $current_image);
            }
        }
    }

    $stmt = $db->prepare("UPDATE services SET title = ?, description = ?, image = ? WHERE id = ?");
    $stmt->bind_param('sssi', $title, $description, $image, $id);
    $stmt->execute();
    header('Location: /admin/services.php?success=updated');
    exit;
}

// Обработка удаления сервиса
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $db->prepare("SELECT image FROM services WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $image = $stmt->get_result()->fetch_assoc()['image'];

    if ($image && file_exists('/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $image)) {
        unlink('/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $image);
    }

    $stmt = $db->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: /admin/services.php?success=deleted');
    exit;
}

// Получение списка сервисов
$services = $db->query("SELECT * FROM services ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Услуги - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/services.php" class="active"><img src="/assets/icons/services.svg" alt="Services"> Услуги</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Услуги</h1>
                <button class="button" onclick="openModal('add-modal')">Добавить услугу</button>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="notification success">
                    <?php
                    if ($_GET['success'] == 'added') echo 'Услуга успешно добавлена!';
                    elseif ($_GET['success'] == 'updated') echo 'Услуга успешно обновлена!';
                    elseif ($_GET['success'] == 'deleted') echo 'Услуга успешно удалена!';
                    ?>
                </div>
            <?php endif; ?>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Изображение</th>
                            <th>Название</th>
                            <th>Описание</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($service = $services->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $service['id']; ?></td>
                                <td>
                                    <img src="/assets/<?php echo htmlspecialchars($service['image']); ?>" alt="<?php echo htmlspecialchars($service['title']); ?>" class="thumbnail">
                                </td>
                                <td><?php echo htmlspecialchars($service['title']); ?></td>
                                <td><?php echo htmlspecialchars($service['description']); ?></td>
                                <td class="actions">
                                    <button class="button secondary" onclick="openEditModal(<?php echo $service['id']; ?>)">Редактировать</button>
                                    <button class="button danger" onclick="if(confirm('Вы уверены?')) location.href='/admin/services.php?delete=<?php echo $service['id']; ?>';">Удалить</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления -->
    <div class="modal" id="add-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('add-modal')">×</span>
            <h2>Добавить услугу</h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Название:</label>
                    <input type="text" name="title" placeholder="Название услуги" required>
                </div>
                <div class="form-group">
                    <label>Описание:</label>
                    <textarea name="description" placeholder="Описание услуги" required></textarea>
                </div>
                <div class="form-group">
                    <label>Изображение:</label>
                    <input type="file" name="image" accept="image/*" required>
                    <div class="image-preview" id="add-image-preview"></div>
                </div>
                <button type="submit" class="button">Добавить услугу</button>
            </form>
        </div>
    </div>

    <!-- Модальное окно для редактирования -->
    <div class="modal" id="edit-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('edit-modal')">×</span>
            <h2>Редактировать услугу</h2>
            <form method="POST" enctype="multipart/form-data" id="edit-form">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit-id">
                <div class="form-group">
                    <label>Название:</label>
                    <input type="text" name="title" id="edit-title" required>
                </div>
                <div class="form-group">
                    <label>Описание:</label>
                    <textarea name="description" id="edit-description" required></textarea>
                </div>
                <div class="form-group">
                    <label>Текущее изображение:</label>
                    <img id="edit-current-image" src="" alt="Текущее изображение" style="max-width: 100px; display: none;">
                </div>
                <div class="form-group">
                    <label>Новое изображение (оставьте пустым, чтобы не менять):</label>
                    <input type="file" name="image" accept="image/*">
                    <div class="image-preview" id="edit-image-preview"></div>
                </div>
                <button type="submit" class="button">Сохранить изменения</button>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.getElementById('add-image-preview').innerHTML = '';
            document.getElementById('edit-image-preview').innerHTML = '';
            document.getElementById('edit-current-image').style.display = 'none';
        }

        // Предпросмотр изображения для добавления
        document.querySelector('#add-modal input[type="file"]').addEventListener('change', function() {
            const preview = document.getElementById('add-image-preview');
            preview.innerHTML = '';
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '100px';
                    preview.appendChild(img);
                };
                reader.readAsDataURL(file);
            }
        });

        // Предпросмотр изображения для редактирования
        document.querySelector('#edit-modal input[type="file"]').addEventListener('change', function() {
            const preview = document.getElementById('edit-image-preview');
            preview.innerHTML = '';
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.maxWidth = '100px';
                    preview.appendChild(img);
                };
                reader.readAsDataURL(file);
            }
        });

        // Открытие модального окна для редактирования
        function openEditModal(id) {
            fetch(`/admin/api/get_service.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit-id').value = data.id;
                    document.getElementById('edit-title').value = data.title;
                    document.getElementById('edit-description').value = data.description;
                    const currentImage = document.getElementById('edit-current-image');
                    currentImage.src = '/assets/' + data.image;
                    currentImage.style.display = 'block';
                    openModal('edit-modal');
                });
        }

        // Автоматическое скрытие уведомлений
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(el => el.remove());
        }, 5000);
    </script>
</body>
</html>
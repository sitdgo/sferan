<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$per_page = 15;
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $per_page;

// Обработка удаления
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $stmt = $db->prepare("DELETE FROM requests WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    // Редирект для обновления страницы
    header("Location: /admin/requests.php?p=$page");
    exit;
}

$total = $db->query("SELECT COUNT(*) FROM requests")->fetch_row()[0];
$pages = ceil($total / $per_page);

$requests = $db->query("SELECT r.*, o.title as object_title FROM requests r LEFT JOIN objects o ON r.object_id = o.id ORDER BY r.created_at DESC LIMIT $per_page OFFSET $offset");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Запросы - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php" class="active"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Запросы</h1>
            </div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Имя</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Объект</th>
                    <th>Сообщение</th>
                    <th>Дата</th>
                    <th>Действия</th>
                </tr>
                <?php while ($request = $requests->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $request['id']; ?></td>
                        <td><?php echo htmlspecialchars($request['name']); ?></td>
                        <td><?php echo htmlspecialchars($request['email']); ?></td>
                        <td><?php echo htmlspecialchars($request['phone']); ?></td>
                        <td><?php echo $request['object_id'] ? htmlspecialchars($request['object_title']) : 'Нет объекта'; ?></td>
                        <td><?php echo nl2br(htmlspecialchars($request['message'])); ?></td>
                        <td><?php echo date('d.m.Y H:i', strtotime($request['created_at'])); ?></td>
                        <td class="actions">
                            <button type="button" class="button danger delete-btn" data-id="<?php echo $request['id']; ?>">Удалить</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="/admin/requests.php?p=<?php echo $page - 1; ?>">❮ Предыдущая</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a href="/admin/requests.php?p=<?php echo $i; ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                <?php if ($page < $pages): ?>
                    <a href="/admin/requests.php?p=<?php echo $page + 1; ?>">Следующая ❯</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.delete-btn');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    if (confirm('Вы уверены, что хотите удалить этот запрос?')) {
                        window.location.href = `/admin/requests.php?delete=${id}&p=<?php echo $page; ?>`;
                    }
                });
            });
        });
    </script>
</body>
</html>
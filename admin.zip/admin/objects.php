<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireLogin();

// Опции для фильтров и подписей
$caption_options = [
    'interior' => 'Интерьер',
    'exterior' => 'Дом снаружи',
    'view' => 'Вид из окна',
    'plan' => 'План квартиры',
    'bathroom' => 'Санузел',
    'hallway' => 'Прихожая',
    'entrance' => 'Подъезд внутри'
];

$renovation_labels = [
    'no_renovation' => 'Без ремонта',
    'designer' => 'Дизайнерский',
    'euro' => 'Евроремонт',
    'cosmetic' => 'Косметический',
    'rough' => 'Черновая отделка',
    'pre_finishing' => 'Предчистовая отделка',
    'finished' => 'Чистовая отделка'
];

// Обработка добавления объекта
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitize($_POST['category']);
    $area = floatval($_POST['area']);
    $rooms = isset($_POST['rooms']) && $_POST['rooms'] !== '' ? intval($_POST['rooms']) : NULL;
    $address = sanitize($_POST['address']);
    $city = sanitize($_POST['city']);
    $status = sanitize($_POST['status']);
    $floors = isset($_POST['floors']) && $_POST['floors'] !== '' ? intval($_POST['floors']) : NULL;
    $floor = isset($_POST['floor']) && $_POST['floor'] !== '' ? intval($_POST['floor']) : NULL;
    $renovation = sanitize($_POST['renovation'] ?? 'no_renovation');

    $images = [];
    $image_captions = [];
    $main_image = 0;
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $maxFiles = 30;

    if (!empty($_FILES['images']['name'][0])) {
        $totalFiles = count($_FILES['images']['name']);
        $totalFiles = min($totalFiles, $maxFiles);
        for ($i = 0; $i < $totalFiles; $i++) {
            $fileName = $_FILES['images']['name'][$i];
            $fileTmp = $_FILES['images']['tmp_name'][$i];
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $newFileName = uniqid() . '.' . $fileExt;
            $uploadDir = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/uploads/';
            $dest = $uploadDir . $newFileName;

            if (in_array($fileExt, $allowed)) {
                if (move_uploaded_file($fileTmp, $dest)) {
                    $webpDest = $uploadDir . uniqid() . '.webp';
                    $image = imagecreatefromstring(file_get_contents($dest));
                    if ($image) {
                        imagewebp($image, $webpDest, 80);
                        imagedestroy($image);
                        unlink($dest);
                        $images[] = 'uploads/' . basename($webpDest);
                    } else {
                        $images[] = 'uploads/' . $newFileName;
                    }
                    $caption = isset($_POST['image_captions'][$i]) ? sanitize($_POST['image_captions'][$i]) : '';
                    $image_captions[] = $caption;
                }
            }
        }
        if (isset($_POST['main_image']) && isset($images[$_POST['main_image']])) {
            $main_image = intval($_POST['main_image']);
        }
    }
    $imagesJson = json_encode([
        'files' => $images,
        'captions' => $image_captions,
        'main' => $main_image
    ]);

    $stmt = $db->prepare("INSERT INTO objects (title, description, price, category, area, rooms, address, city, status, floors, floor, renovation, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('ssdsiisssiiss', $title, $description, $price, $category, $area, $rooms, $address, $city, $status, $floors, $floor, $renovation, $imagesJson);
    $stmt->execute();
    header('Location: /admin/objects.php?success=added');
    exit;
}

// Обновление объекта
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = intval($_POST['id']);
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitize($_POST['category']);
    $area = floatval($_POST['area']);
    $rooms = isset($_POST['rooms']) && $_POST['rooms'] !== '' ? intval($_POST['rooms']) : NULL;
    $address = sanitize($_POST['address']);
    $city = sanitize($_POST['city']);
    $status = sanitize($_POST['status']);
    $floors = isset($_POST['floors']) && $_POST['floors'] !== '' ? intval($_POST['floors']) : NULL;
    $floor = isset($_POST['floor']) && $_POST['floor'] !== '' ? intval($_POST['floor']) : NULL;
    $renovation = sanitize($_POST['renovation'] ?? 'no_renovation');

    $stmt = $db->prepare("SELECT images FROM objects WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $current_images = json_decode($result['images'], true);
    $images = $current_images['files'] ?? [];
    $image_captions = $current_images['captions'] ?? [];
    $main_image = $current_images['main'] ?? 0;

    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $maxFiles = 30;
    if (!empty($_FILES['images']['name'][0])) {
        $totalFiles = count($_FILES['images']['name']);
        $totalFiles = min($totalFiles, $maxFiles - count($images));
        for ($i = 0; $i < $totalFiles; $i++) {
            $fileName = $_FILES['images']['name'][$i];
            $fileTmp = $_FILES['images']['tmp_name'][$i];
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $newFileName = uniqid() . '.' . $fileExt;
            $uploadDir = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/uploads/';
            $dest = $uploadDir . $newFileName;

            if (in_array($fileExt, $allowed)) {
                if (move_uploaded_file($fileTmp, $dest)) {
                    $webpDest = $uploadDir . uniqid() . '.webp';
                    $image = imagecreatefromstring(file_get_contents($dest));
                    if ($image) {
                        imagewebp($image, $webpDest, 80);
                        imagedestroy($image);
                        unlink($dest);
                        $images[] = 'uploads/' . basename($webpDest);
                    } else {
                        $images[] = 'uploads/' . $newFileName;
                    }
                    $caption = isset($_POST['image_captions'][$i]) ? sanitize($_POST['image_captions'][$i]) : '';
                    $image_captions[] = $caption;
                }
            }
        }
    }

    if (isset($_POST['existing_captions'])) {
        foreach ($_POST['existing_captions'] as $index => $caption) {
            if (isset($image_captions[$index])) {
                $image_captions[$index] = sanitize($caption);
            }
        }
    }

    if (isset($_POST['delete_images'])) {
        foreach ($_POST['delete_images'] as $index) {
            $index = intval($index);
            if (isset($images[$index])) {
                $filePath = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $images[$index];
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
                unset($images[$index]);
                unset($image_captions[$index]);
            }
        }
        $images = array_values($images);
        $image_captions = array_values($image_captions);
    }

    if (isset($_POST['main_image']) && isset($images[$_POST['main_image']])) {
        $main_image = intval($_POST['main_image']);
    }

    $imagesJson = json_encode([
        'files' => $images,
        'captions' => $image_captions,
        'main' => $main_image
    ]);

    $stmt = $db->prepare("UPDATE objects SET title = ?, description = ?, price = ?, category = ?, area = ?, rooms = ?, address = ?, city = ?, status = ?, floors = ?, floor = ?, renovation = ?, images = ? WHERE id = ?");
    $stmt->bind_param('ssdsiisssiissi', $title, $description, $price, $category, $area, $rooms, $address, $city, $status, $floors, $floor, $renovation, $imagesJson, $id);
    $stmt->execute();
    header('Location: /admin/objects.php?success=updated');
    exit;
}

// Массовые действия
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action']) && isset($_POST['selected_objects'])) {
    $action = sanitize($_POST['bulk_action']);
    $selected_objects = array_map('intval', $_POST['selected_objects']);

    if ($action === 'delete') {
        foreach ($selected_objects as $id) {
            $stmt = $db->prepare("SELECT images FROM objects WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result) {
                $images_data = json_decode($result['images'], true);
                $images = $images_data['files'] ?? [];
                foreach ($images as $image) {
                    $filePath = '/var/www/u2911633/data/www/new.sitdgo.pro/assets/' . $image;
                    if (file_exists($filePath)) {
                        unlink($filePath);
                    }
                }
                $stmt = $db->prepare("DELETE FROM objects WHERE id = ?");
                $stmt->bind_param('i', $id);
                $stmt->execute();
            }
        }
    } elseif ($action === 'change_status' && isset($_POST['bulk_status'])) {
        $new_status = sanitize($_POST['bulk_status']);
        foreach ($selected_objects as $id) {
            $stmt = $db->prepare("UPDATE objects SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $new_status, $id);
            $stmt->execute();
        }
    } elseif ($action === 'duplicate') {
        foreach ($selected_objects as $id) {
            $stmt = $db->prepare("SELECT * FROM objects WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $object = $stmt->get_result()->fetch_assoc();
            if ($object) {
                $stmt = $db->prepare("INSERT INTO objects (title, description, price, category, area, rooms, address, city, status, floors, floor, renovation, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('ssdsiisssiiss', $object['title'], $object['description'], $object['price'], $object['category'], $object['area'], $object['rooms'], $object['address'], $object['city'], $object['status'], $object['floors'], $object['floor'], $object['renovation'], $object['images']);
                $stmt->execute();
            }
        }
    }
    header('Location: /admin/objects.php?success=bulk');
    exit;
}

// Фильтры и сортировка
$per_page = 20;
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $per_page;

$where = [];
$params = [];
$types = '';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$category = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$city = isset($_GET['city']) ? sanitize($_GET['city']) : '';
$renovation = isset($_GET['renovation']) ? sanitize($_GET['renovation']) : '';
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'created_at DESC';

if ($search) {
    $where[] = "(title LIKE ? OR city LIKE ? OR address LIKE ?)";
    $like_search = '%' . $search . '%';
    $params[] = $like_search;
    $params[] = $like_search;
    $params[] = $like_search;
    $types .= 'sss';
}
if ($category) {
    $where[] = "category = ?";
    $params[] = $category;
    $types .= 's';
}
if ($status) {
    $where[] = "status = ?";
    $params[] = $status;
    $types .= 's';
}
if ($city) {
    $where[] = "city = ?";
    $params[] = $city;
    $types .= 's';
}
if ($renovation) {
    $where[] = "renovation = ?";
    $params[] = $renovation;
    $types .= 's';
}

$where_clause = $where ? "WHERE " . implode(" AND ", $where) : "";
$total_query = "SELECT COUNT(*) FROM objects $where_clause";
$stmt = $db->prepare($total_query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = $stmt->get_result()->fetch_row()[0];
$pages = ceil($total / $per_page);

$query = "SELECT * FROM objects $where_clause ORDER BY $sort LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;
$types .= 'ii';

$stmt = $db->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$objects = $stmt->get_result();

$cities = $db->query("SELECT DISTINCT city FROM objects WHERE city IS NOT NULL ORDER BY city")->fetch_all(MYSQLI_ASSOC);

// Данные для редактирования
$edit_object = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $db->prepare("SELECT * FROM objects WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $edit_object = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Объекты - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php" class="active"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Объекты</h1>
                <div>
                    <button class="button" onclick="openModal('add-modal')">Добавить объект</button>
                </div>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="notification success">
                    <?php
                    if ($_GET['success'] == 'added') echo 'Объект успешно добавлен!';
                    elseif ($_GET['success'] == 'updated') echo 'Объект успешно обновлен!';
                    elseif ($_GET['success'] == 'bulk') echo 'Массовое действие выполнено!';
                    ?>
                </div>
            <?php endif; ?>

            <div class="search-bar">
                <input type="text" id="search-input" placeholder="Поиск по названию, городу, адресу..." value="<?php echo htmlspecialchars($search); ?>">
                <button class="button" onclick="applyFilters()">Поиск</button>
            </div>

            <div class="filters">
                <select id="filter-category">
                    <option value="">Все категории</option>
                    <option value="apartment" <?php echo $category == 'apartment' ? 'selected' : ''; ?>>Квартира</option>
                    <option value="house" <?php echo $category == 'house' ? 'selected' : ''; ?>>Дом</option>
                    <option value="commercial" <?php echo $category == 'commercial' ? 'selected' : ''; ?>>Коммерческая</option>
                </select>
                <select id="filter-status">
                    <option value="">Все статусы</option>
                    <option value="available" <?php echo $status == 'available' ? 'selected' : ''; ?>>Доступен</option>
                    <option value="sold" <?php echo $status == 'sold' ? 'selected' : ''; ?>>Продан</option>
                    <option value="reserved" <?php echo $status == 'reserved' ? 'selected' : ''; ?>>В резерве</option>
                </select>
                <select id="filter-city">
                    <option value="">Все города</option>
                    <?php foreach ($cities as $c): ?>
                        <option value="<?php echo htmlspecialchars($c['city']); ?>" <?php echo $city == $c['city'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($c['city']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select id="filter-renovation">
                    <option value="">Все типы ремонта</option>
                    <?php foreach ($renovation_labels as $value => $label): ?>
                        <option value="<?php echo $value; ?>" <?php echo $renovation == $value ? 'selected' : ''; ?>>
                            <?php echo $label; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select id="sort">
                    <option value="created_at DESC" <?php echo $sort == 'created_at DESC' ? 'selected' : ''; ?>>Новые</option>
                    <option value="price ASC" <?php echo $sort == 'price ASC' ? 'selected' : ''; ?>>Дешевые</option>
                    <option value="price DESC" <?php echo $sort == 'price DESC' ? 'selected' : ''; ?>>Дорогие</option>
                    <option value="area ASC" <?php echo $sort == 'area ASC' ? 'selected' : ''; ?>>Меньшая площадь</option>
                    <option value="area DESC" <?php echo $sort == 'area DESC' ? 'selected' : ''; ?>>Большая площадь</option>
                </select>
                <button class="button" onclick="applyFilters()">Фильтровать</button>
                <button class="button secondary" onclick="resetFilters()">Сбросить</button>
            </div>

            <form method="POST" id="bulk-form">
                <div class="filters">
                    <select name="bulk_action">
                        <option value="">Массовые действия</option>
                        <option value="delete">Удалить</option>
                        <option value="change_status">Изменить статус</option>
                        <option value="duplicate">Дублировать</option>
                    </select>
                    <select name="bulk_status" style="display: none;">
                        <option value="available">Доступен</option>
                        <option value="sold">Продан</option>
                        <option value="reserved">В резерве</option>
                    </select>
                    <button type="submit" class="button">Применить</button>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="select-all"></th>
                                <th>ID</th>
                                <th>Изображение</th>
                                <th>Название</th>
                                <th>Цена</th>
                                <th>Категория</th>
                                <th>Статус</th>
                                <th>Город</th>
                                <th>Ремонт</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody id="objects-table">
                            <?php while ($object = $objects->fetch_assoc()): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_objects[]" value="<?php echo $object['id']; ?>"></td>
                                    <td><?php echo $object['id']; ?></td>
                                    <td>
                                        <?php
                                        $images_data = json_decode($object['images'], true);
                                        $images = $images_data['files'] ?? [];
                                        $main_image = $images_data['main'] ?? 0;
                                        $main_image_file = $images[$main_image] ?? 'images/placeholder.jpg';
                                        ?>
                                        <img src="/assets/<?php echo $main_image_file; ?>" alt="Thumbnail" class="thumbnail">
                                    </td>
                                    <td><?php echo htmlspecialchars($object['title']); ?></td>
                                    <td><?php echo number_format($object['price'], 2); ?> ₽</td>
                                    <td><?php echo $object['category'] == 'apartment' ? 'Квартира' : ($object['category'] == 'house' ? 'Дом' : 'Коммерческая'); ?></td>
                                    <td><?php echo $object['status'] == 'available' ? 'Доступен' : ($object['status'] == 'sold' ? 'Продан' : 'В резерве'); ?></td>
                                    <td><?php echo htmlspecialchars($object['city']); ?></td>
                                    <td><?php echo $renovation_labels[$object['renovation']] ?? 'Не указан'; ?></td>
                                    <td class="actions">
                                        <a href="/index.php?page=object&id=<?php echo $object['id']; ?>" class="button">Просмотр</a>
                                        <button type="button" class="button secondary" onclick="openEditModal(<?php echo $object['id']; ?>)">Редактировать</button>
                                        <button type="button" class="button danger" onclick="if(confirm('Вы уверены?')) location.href='/admin/objects.php?delete=<?php echo $object['id']; ?>';">Удалить</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </form>

            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="/admin/objects.php?p=<?php echo $page - 1; ?>&<?php echo http_build_query($_GET, '', '&'); ?>">❮ Предыдущая</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a href="/admin/objects.php?p=<?php echo $i; ?>&<?php echo http_build_query($_GET, '', '&'); ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                <?php if ($page < $pages): ?>
                    <a href="/admin/objects.php?p=<?php echo $page + 1; ?>&<?php echo http_build_query($_GET, '', '&'); ?>">Следующая ❯</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Модальное окно для добавления -->
    <div class="modal" id="add-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('add-modal')">&times;</span>
            <h2>Добавить объект</h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Название:</label>
                    <input type="text" name="title" placeholder="Название объекта" required>
                </div>
                <div class="form-group">
                    <label>Описание:</label>
                    <textarea name="description" placeholder="Описание объекта" required></textarea>
                </div>
                <div class="form-group">
                    <label>Цена (₽):</label>
                    <input type="number" name="price" step="0.01" placeholder="Цена" required>
                </div>
                <div class="form-group">
                    <label>Категория:</label>
                    <select name="category" required>
                        <option value="apartment">Квартира</option>
                        <option value="house">Дом</option>
                        <option value="commercial">Коммерческая</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Площадь (м²):</label>
                    <input type="number" name="area" step="0.1" placeholder="Площадь" required>
                </div>
                <div class="form-group">
                    <label>Комнат:</label>
                    <input type="number" name="rooms" placeholder="Количество комнат" min="0">
                </div>
                <div class="form-group">
                    <label>Этажей в доме:</label>
                    <input type="number" name="floors" placeholder="Количество этажей в доме" min="1">
                </div>
                <div class="form-group">
                    <label>Этаж квартиры:</label>
                    <input type="number" name="floor" placeholder="Этаж" min="1">
                </div>
                <div class="form-group">
                    <label>Ремонт:</label>
                    <select name="renovation">
                        <option value="no_renovation">Без ремонта</option>
                        <option value="designer">Дизайнерский</option>
                        <option value="euro">Евроремонт</option>
                        <option value="cosmetic">Косметический</option>
                        <option value="rough">Черновая отделка</option>
                        <option value="pre_finishing">Предчистовая отделка</option>
                        <option value="finished">Чистовая отделка</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Адрес:</label>
                    <input type="text" name="address" placeholder="Адрес" required>
                </div>
                <div class="form-group">
                    <label>Город:</label>
                    <input type="text" name="city" placeholder="Город" required>
                </div>
                <div class="form-group">
                    <label>Статус:</label>
                    <select name="status" required>
                        <option value="available">Доступен</option>
                        <option value="sold">Продан</option>
                        <option value="reserved">В резерве</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Изображения (до 30 файлов):</label>
                    <input type="file" name="images[]" id="add-image-upload" multiple accept="image/*" required>
                    <div class="image-preview" id="add-images"></div>
                </div>
                <button type="submit" class="button">Добавить объект</button>
            </form>
        </div>
    </div>

    <!-- Модальное окно для редактирования -->
    <div class="modal" id="edit-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal('edit-modal')">&times;</span>
            <h2>Редактировать объект</h2>
            <form method="POST" enctype="multipart/form-data" id="edit-form">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit-id">
                <div class="form-group">
                    <label>Название:</label>
                    <input type="text" name="title" id="edit-title" required>
                </div>
                <div class="form-group">
                    <label>Описание:</label>
                    <textarea name="description" id="edit-description" required></textarea>
                </div>
                <div class="form-group">
                    <label>Цена (₽):</label>
                    <input type="number" name="price" id="edit-price" step="0.01" required>
                </div>
                <div class="form-group">
                    <label>Категория:</label>
                    <select name="category" id="edit-category" required>
                        <option value="apartment">Квартира</option>
                        <option value="house">Дом</option>
                        <option value="commercial">Коммерческая</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Площадь (м²):</label>
                    <input type="number" name="area" id="edit-area" step="0.1" required>
                </div>
                <div class="form-group">
                    <label>Комнат:</label>
                    <input type="number" name="rooms" id="edit-rooms" min="0">
                </div>
                <div class="form-group">
                    <label>Этажей в доме:</label>
                    <input type="number" name="floors" id="edit-floors" min="1">
                </div>
                <div class="form-group">
                    <label>Этаж квартиры:</label>
                    <input type="number" name="floor" id="edit-floor" min="1">
                </div>
                <div class="form-group">
                    <label>Ремонт:</label>
                    <select name="renovation" id="edit-renovation">
                        <option value="no_renovation">Без ремонта</option>
                        <option value="designer">Дизайнерский</option>
                        <option value="euro">Евроремонт</option>
                        <option value="cosmetic">Косметический</option>
                        <option value="rough">Черновая отделка</option>
                        <option value="pre_finishing">Предчистовая отделка</option>
                        <option value="finished">Чистовая отделка</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Адрес:</label>
                    <input type="text" name="address" id="edit-address" required>
                </div>
                <div class="form-group">
                    <label>Город:</label>
                    <input type="text" name="city" id="edit-city" required>
                </div>
                <div class="form-group">
                    <label>Статус:</label>
                    <select name="status" id="edit-status" required>
                        <option value="available">Доступен</option>
                        <option value="sold">Продан</option>
                        <option value="reserved">В резерве</option>
                    </select>
                </div>
                <div class="form-group" id="edit-existing-images-group" style="display: none;">
                    <label>Текущие изображения:</label>
                    <div class="image-preview" id="edit-existing-images"></div>
                </div>
                <div class="form-group">
                    <label>Новые изображения (до 30 файлов):</label>
                    <input type="file" name="images[]" id="edit-image-upload" multiple accept="image/*">
                    <div class="image-preview" id="edit-new-images"></div>
                </div>
                <button type="submit" class="button">Сохранить изменения</button>
            </form>
        </div>
    </div>

    <script>
        // Открытие/закрытие модальных окон
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            if (modalId === 'add-modal') {
                document.getElementById('add-images').innerHTML = '';
            }
            if (modalId === 'edit-modal') {
                document.getElementById('edit-existing-images').innerHTML = '';
                document.getElementById('edit-new-images').innerHTML = '';
            }
        }

        // Выбор всех чекбоксов
        document.getElementById('select-all').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[name="selected_objects[]"]');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });

        // Показ/скрытие поля выбора статуса для массовых действий
        document.querySelector('select[name="bulk_action"]').addEventListener('change', function() {
            const bulkStatus = document.querySelector('select[name="bulk_status"]');
            bulkStatus.style.display = this.value === 'change_status' ? 'block' : 'none';
        });

        // Предпросмотр изображений для добавления
        const addImageUpload = document.getElementById('add-image-upload');
        const addImagesContainer = document.getElementById('add-images');
        addImageUpload.addEventListener('change', function() {
            addImagesContainer.innerHTML = '';
            for (let i = 0; i < this.files.length; i++) {
                const file = this.files[i];
                const reader = new FileReader();
                reader.onload = function(e) {
                    const div = document.createElement('div');
                    div.className = 'image-item';
                    div.innerHTML = `
                        <img src="${e.target.result}" alt="Preview">
                        <button type="button" class="delete-image" data-index="${i}">×</button>
                        <select name="image_captions[${i}]" class="caption-select">
                            <option value="">Без подписи</option>
                            <?php foreach ($caption_options as $value => $label): ?>
                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="radio" name="main_image" value="${i}" ${i === 0 ? 'checked' : ''} style="display: none;">
                    `;
                    addImagesContainer.appendChild(div);

                    div.querySelector('img').addEventListener('click', function() {
                        addImagesContainer.querySelectorAll('img').forEach(img => img.classList.remove('main'));
                        this.classList.add('main');
                        const radio = this.parentElement.querySelector('input[type="radio"]');
                        radio.checked = true;
                    });

                    div.querySelector('.delete-image').addEventListener('click', function() {
                        div.remove();
                    });
                };
                reader.readAsDataURL(file);
            }
        });

        // Предпросмотр новых изображений для редактирования
        const editImageUpload = document.getElementById('edit-image-upload');
        const editNewImagesContainer = document.getElementById('edit-new-images');
        editImageUpload.addEventListener('change', function() {
            editNewImagesContainer.innerHTML = '';
            for (let i = 0; i < this.files.length; i++) {
                const file = this.files[i];
                const reader = new FileReader();
                reader.onload = function(e) {
                    const div = document.createElement('div');
                    div.className = 'image-item';
                    div.innerHTML = `
                        <img src="${e.target.result}" alt="Preview">
                        <button type="button" class="delete-image" data-index="${i}">×</button>
                        <select name="image_captions[${i}]" class="caption-select">
                            <option value="">Без подписи</option>
                            <?php foreach ($caption_options as $value => $label): ?>
                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="radio" name="main_image" value="${i}" ${i === 0 ? 'checked' : ''} style="display: none;">
                    `;
                    editNewImagesContainer.appendChild(div);

                    div.querySelector('img').addEventListener('click', function() {
                        const allImages = [...editNewImagesContainer.querySelectorAll('img'), ...document.getElementById('edit-existing-images').querySelectorAll('img')];
                        allImages.forEach(img => img.classList.remove('main'));
                        this.classList.add('main');
                        const radio = this.parentElement.querySelector('input[type="radio"]');
                        radio.checked = true;
                    });

                    div.querySelector('.delete-image').addEventListener('click', function() {
                        div.remove();
                    });
                };
                reader.readAsDataURL(file);
            }
        });

        // Открытие модального окна для редактирования
        function openEditModal(id) {
            fetch(`/admin/api/get_object.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit-id').value = data.id;
                    document.getElementById('edit-title').value = data.title;
                    document.getElementById('edit-description').value = data.description;
                    document.getElementById('edit-price').value = data.price;
                    document.getElementById('edit-category').value = data.category;
                    document.getElementById('edit-area').value = data.area;
                    document.getElementById('edit-rooms').value = data.rooms || '';
                    document.getElementById('edit-floors').value = data.floors || '';
                    document.getElementById('edit-floor').value = data.floor || '';
                    document.getElementById('edit-renovation').value = data.renovation;
                    document.getElementById('edit-address').value = data.address;
                    document.getElementById('edit-city').value = data.city;
                    document.getElementById('edit-status').value = data.status;

                    const imagesData = JSON.parse(data.images);
                    const images = imagesData.files || [];
                    const captions = imagesData.captions || [];
                    const mainImage = imagesData.main || 0;
                    const existingImagesContainer = document.getElementById('edit-existing-images');
                    existingImagesContainer.innerHTML = '';

                    if (images.length > 0) {
                        document.getElementById('edit-existing-images-group').style.display = 'block';
                        images.forEach((image, index) => {
                            const div = document.createElement('div');
                            div.className = 'image-item';
                            div.innerHTML = `
                                <img src="/assets/${image}" alt="Preview" class="${index == mainImage ? 'main' : ''}" data-index="${index}">
                                <button type="button" class="delete-image" data-index="${index}">×</button>
                                <select name="existing_captions[${index}]" class="caption-select">
                                    <option value="">Без подписи</option>
                                    <?php foreach ($caption_options as $value => $label): ?>
                                        <option value="<?php echo $value; ?>" ${captions[index] === '<?php echo $value; ?>' ? 'selected' : ''}>
                                            <?php echo $label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="radio" name="main_image" value="${index}" ${index == mainImage ? 'checked' : ''} style="display: none;">
                            `;
                            existingImagesContainer.appendChild(div);

                            div.querySelector('img').addEventListener('click', function() {
                                const allImages = [...existingImagesContainer.querySelectorAll('img'), ...document.getElementById('edit-new-images').querySelectorAll('img')];
                                allImages.forEach(img => img.classList.remove('main'));
                                this.classList.add('main');
                                const radio = this.parentElement.querySelector('input[type="radio"]');
                                radio.checked = true;
                            });

                            div.querySelector('.delete-image').addEventListener('click', function() {
                                const input = document.createElement('input');
                                input.type = 'hidden';
                                input.name = 'delete_images[]';
                                input.value = this.getAttribute('data-index');
                                existingImagesContainer.appendChild(input);
                                div.remove();
                            });
                        });
                    } else {
                        document.getElementById('edit-existing-images-group').style.display = 'none';
                    }

                    openModal('edit-modal');
                });
        }

        // Применение фильтров
        function applyFilters() {
            const search = document.getElementById('search-input').value;
            const category = document.getElementById('filter-category').value;
            const status = document.getElementById('filter-status').value;
            const city = document.getElementById('filter-city').value;
            const renovation = document.getElementById('filter-renovation').value;
            const sort = document.getElementById('sort').value;

            const params = new URLSearchParams();
            if (search) params.append('search', search);
            if (category) params.append('category', category);
            if (status) params.append('status', status);
            if (city) params.append('city', city);
            if (renovation) params.append('renovation', renovation);
            if (sort) params.append('sort', sort);

            window.location.href = `/admin/objects.php?${params.toString()}`;
        }

        // Сброс фильтров
        function resetFilters() {
            window.location.href = '/admin/objects.php';
        }

        // Автоматическое скрытие уведомлений
        setTimeout(() => {
            document.querySelectorAll('.notification').forEach(el => el.remove());
        }, 5000);
    </script>
</body>
</html>
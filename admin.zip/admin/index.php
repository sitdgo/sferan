<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$total_objects = $db->query("SELECT COUNT(*) FROM objects")->fetch_row()[0];
$total_requests = $db->query("SELECT COUNT(*) FROM requests")->fetch_row()[0];
$total_reviews = $db->query("SELECT COUNT(*) FROM reviews")->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления - Сфера-Н</title>
    <link rel="stylesheet" href="/assets/css/admin.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="admin-wrapper">
        <aside class="sidebar">
            <h2>Сфера-Н</h2>
            <nav>
                <a href="/admin/index.php" class="active"><img src="/assets/icons/dashboard.svg" alt="Dashboard"> Панель управления</a>
                <a href="/admin/objects.php"><img src="/assets/icons/objects.svg" alt="Objects"> Объекты</a>
				<a href="/admin/services.php"><img src="/assets/icons/services.svg" alt="Services"> Услуги</a>
                <a href="/admin/requests.php"><img src="/assets/icons/requests.svg" alt="Requests"> Запросы</a>
                <a href="/admin/reviews.php"><img src="/assets/icons/reviews.svg" alt="Reviews"> Отзывы</a>
                <a href="/admin/stats.php"><img src="/assets/icons/stats.svg" alt="Stats"> Статистика</a>
                <a href="/admin/logout.php" class="logout"><img src="/assets/icons/logout.svg" alt="Logout"> Выйти</a>
            </nav>
        </aside>
        <div class="admin-content">
            <div class="admin-header">
                <h1>Панель управления</h1>
            </div>
            <div class="stats">
                <h2>Общая статистика</h2>
                <ul>
                    <li>Всего объектов: <strong><?php echo $total_objects; ?></strong></li>
                    <li>Всего запросов: <strong><?php echo $total_requests; ?></strong></li>
                    <li>Всего отзывов: <strong><?php echo $total_reviews; ?></strong></li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
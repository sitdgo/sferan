/* /var/www/u2911633/data/www/new.sitdgo.pro/assets/js/custom-slider.js */
document.addEventListener('DOMContentLoaded', function () {
    console.log('Инициализация нового слайдера...');

    const sliderTrack = document.querySelector('.slider-track');
    const slides = document.querySelectorAll('.service-item.slide');
    const prevButton = document.querySelector('.slider-prev');
    const nextButton = document.querySelector('.slider-next');
    const servicesSlider = document.querySelector('.services-slider');

    if (!sliderTrack || !slides.length || !prevButton || !nextButton || !servicesSlider) {
        console.error('Ошибка: Не найдены необходимые элементы слайдера.', {
            sliderTrack: !!sliderTrack,
            slides: slides.length,
            prevButton: !!prevButton,
            nextButton: !!nextButton,
            servicesSlider: !!servicesSlider
        });
        return;
    }

    console.log('Найдено слайдов в DOM:', slides.length);

    let slidesToShow = 3;
    let currentIndex = 0;
    let autoSlideInterval = null;

    function updateSlidesToShow() {
        if (window.innerWidth <= 480) {
            slidesToShow = 1;
        } else if (window.innerWidth <= 768) {
            slidesToShow = 2;
        } else {
            slidesToShow = 3;
        }
        const totalSlides = slides.length;
        const maxIndex = Math.ceil(totalSlides / slidesToShow) - 1;
        currentIndex = Math.min(currentIndex, maxIndex);
        const totalWidth = (100 * totalSlides) / slidesToShow; // Динамическая ширина для .slider-track
        sliderTrack.style.width = `${totalWidth}%`;
        const offset = -currentIndex * (100 / slidesToShow);
        sliderTrack.style.transform = `translateX(${offset}%)`;
        console.log('Обновление слайдера: slidesToShow=', slidesToShow, 'totalSlides=', totalSlides, 'maxIndex=', maxIndex, 'currentIndex=', currentIndex, 'totalWidth=', totalWidth);
    }

    function moveSlider(direction) {
        const totalSlides = slides.length;
        const maxIndex = Math.ceil(totalSlides / slidesToShow) - 1;
        if (direction === 'next') {
            currentIndex = (currentIndex < maxIndex) ? currentIndex + 1 : 0;
        } else if (direction === 'prev') {
            currentIndex = (currentIndex > 0) ? currentIndex - 1 : maxIndex;
        }
        const offset = -currentIndex * (100 / slidesToShow);
        sliderTrack.style.transform = `translateX(${offset}%)`;
        console.log('Переключение слайда: currentIndex=', currentIndex, 'offset=', offset);
    }

    updateSlidesToShow();
    window.addEventListener('resize', updateSlidesToShow);

    prevButton.addEventListener('click', function () {
        console.log('Клик по кнопке "Предыдущий"');
        moveSlider('prev');
        clearInterval(autoSlideInterval);
        startAutoSlide();
    });

    nextButton.addEventListener('click', function () {
        console.log('Клик по кнопке "Следующий"');
        moveSlider('next');
        clearInterval(autoSlideInterval);
        startAutoSlide();
    });

    function startAutoSlide() {
        console.log('Запуск автопрокрутки');
        clearInterval(autoSlideInterval);
        autoSlideInterval = setInterval(function () {
            console.log('Автопрокрутка: переключаем на следующий слайд');
            moveSlider('next');
        }, 5000);
    }

    startAutoSlide();

    servicesSlider.addEventListener('mouseenter', function () {
        console.log('Наведение на слайдер: остановка автопрокрутки');
        clearInterval(autoSlideInterval);
    });

    servicesSlider.addEventListener('mouseleave', function () {
        console.log('Уход курсора с слайдера: возобновление автопрокрутки');
        startAutoSlide();
    });
});